"""
repository for all variables used in pycrash modulues
"""
definitions = {
'delta_deg':'tire steer angle (degrees)',
'delta_rad':'tire steer angle (radians)',
'beta_deg':'velocity vectory in intertial reference frame (degrees)',
'beta_rad':'velocity vectory in intertial reference frame (radians)',
'lf_alpha':'left front tire slip angle in tire reference frame (radians)',

}
