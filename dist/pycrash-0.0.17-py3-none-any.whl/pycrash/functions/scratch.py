x = [1, 2, 3, 4, 5]

z = [1, 4]

w = list( x[i] for i in z)
print(w)
