"""
impulse momentum model based on Carpenter 2020 SAE
results will update the linear and rotational velocity for each vehicle
TODO: allow for a pulse duration to be used to generate the impact response and estimate acceleration
"""


# impulse momentum model is only run once per simulation
